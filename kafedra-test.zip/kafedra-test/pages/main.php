<?php
/**
 * Created by PhpStorm.
 * User: kalenyukk
 * Date: 22.08.2017
 * Time: 21:23
 */

?>


<!DOCTYPE html>

<html>
<head>
<link rel="shortcut icon" type="image/x-icon" href="../images/icon.ico">
<title>Кафедра Фотоники И Лазерной Инженерии</title>
<meta charset="utf-8">
<!--<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> -->
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link href="../layout/styles/header.css" rel="stylesheet" type="text/css" />

</head>
<body id="top">
<style type="text/css"></style>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<content>
    <!-- HEADER -->
    <header>

      <!-- MENU BLOCK -->
      <div class="menu_block">

        <!-- CONTAINER -->
     <!--   <div class="container clearfix"> -->

          <!-- LOGO -->
          <div class="logo pull-left">
          <img src="../nure1.png">

          </div><!-- //LOGO -->

          <!-- SEARCH FORM
          <div id="search-form" class="pull-right">
            <form method="get" action="#">
              <input type="text" name="Search" value="Search" onFocus="if (this.value == 'Search') this.value = '';" onBlur="if (this.value == '') this.value = 'Search';" />
            </form>
          </div>
          SEARCH FORM -->

          <!-- MENU -->
          <div class="pull-right">
            <nav class="navmenu center">
              <ul>
                <li class="first active scroll_btn"><a href="#top" >Главная</a></li>
                <li class="scroll_btn"><a href="pages/photogallery.php" >Галерея</a></li>
                <li class="scroll_btn"><a href="#" >Абитуриенту</a></li>
                <li class="scroll_btn"><a href="#">Новости</a></li>
                <li class="scroll_btn"><a href="#">О Кафедре</a></li>
                <li class="scroll_btn"><a href="http://cist.nure.ua/ias/app/tt/f?p=778:2:1917547441500311::NO#" >Расписание</a></li>
                <li class="scroll_btn last"><a href="#to_contact" >Контакты</a>
              </ul>
                </li>
              </ul>
            </nav>
          </div><!-- //MENU -->
        </div><!-- //MENU BLOCK -->
      </div><!-- //CONTAINER -->
    </header><!-- //HEADER -->
    </ul>
    <!-- ################################################################################################ -->
  </nav>

</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

<!--SLIDESHOW -->




<div class="wrapper bgded" style="background-color: rgba(242, 241, 238, 0.8); margin-bottom: 3%; margin-top: 200px; ">



<div id="pageintro" class="hoc clear">


    <!-- ################################################################################################ -->
    <article>
      <div class="overlay inspace-30 btmspace-30">
        <h2 class="heading">Основные функции</h2>
        <p>На кафедре проводится подготовка бакалавров, специалистов и магистров по специальностям «Оптотехника» и «Лазерная и оптоэлектронная техника» с присвоением квалификации «специалист по электронике» бакалавру, «инженер-электроник» - специалисту, «научный сотрудник (электроника, телекоммуникации)» - магистру. Срок обучения бакалавра составляет 3 года и 10 месяцев, подготовка магистров и специалистов – 1 год.
            Профессорско-преподавательский состав кафедры включает 2-х лауреатов государственной премии, 3-х академиков и одного члена-корреспондента  Академии наук прикладной радиоэлектроники, 5 профессоров, 4 докторов наук, 7 доцентов, 9 кандидатов наук.
            На кафедре есть 6 учебных лабораторий, оснащенных современной техникой. Лаборатории для изучения лазеров и пассивных оптических элементов, лаборатории для исследования спектров и физических явлений, которые лежат в основе каждого оптического прибора, лаборатории электроники СВЧ и химические лаборатории.
            На кафедре ФОЭТ создана и действует студенческая проектная лаборатория (СПЛ)...</p>
      </div>
      <footer>
        <ul class="nospace inline pushright">
          <li><a class="btn" href="#">Читать полностью</a></li>
        </ul>
      </footer>
    </article>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3" style="background-color: rgba(242, 241, 238, 0.8); margin-bottom: 3%;">
  <main class="hoc container clear">
  <div class="article_content_row3">
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50">
      <h2 class="heading">Justo non pulvinar</h2>
      <p>Elit nullam facilisis est quis justo viverra hendrerit donec euismod fringilla justo a auctor.</p>
    </div>
    <article class="one_third first btmspace-50">
      <h3 class="font-x1 btmspace-30"><i class="fa fa-2x fa-500px rightspace-10"></i> <a href="#">Aliquam in lacus</a></h3>
      <p>Bibendum et vestibulum condimentum rutrum arcu sed posuere sem in eu lectus sit amet dolor ultrices suscipit aliquam vestibulum sollicitudin dapibus&hellip;</p>
    </article>
    <article class="one_third btmspace-50">
      <h3 class="font-x1 btmspace-30"><i class="fa fa-2x fa-adjust rightspace-10"></i> <a href="#">Vel velit malesuada</a></h3>
      <p>Nunc enim sapien elementum ac aliquam in tempus a tortor vivamus at arcu ut tellus fermentum rutrum a eu orci vestibulum ante ipsum primis in faucibus&hellip;</p>
    </article>
    <article class="one_third btmspace-50">
      <h3 class="font-x1 btmspace-30"><i class="fa fa-2x fa-leaf rightspace-10"></i> <a href="#">Gravida nec non</a></h3>
      <p>Ultrices posuere cubilia curae nam placerat neque eu elit eleifend gravida ut efficitur lacus et ex ullamcorper eget molestie massa lacinia donec euismod&hellip;</p>
    </article>
    <article class="one_third first">
      <h3 class="font-x1 btmspace-30"><i class="fa fa-2x fa-leanpub rightspace-10"></i> <a href="#">Mauris nam mollis</a></h3>
      <p>Amet nunc feugiat sed volutpat odio mollis duis tellus ante mollis non tellus sit amet facilisis interdum quam morbi imperdiet tincidunt leo ac eleifend&hellip;</p>
    </article>
    <article class="one_third">
      <h3 class="font-x1 btmspace-30"><i class="fa fa-2x fa-legal rightspace-10"></i> <a href="#">Mauris dui sed</a></h3>
      <p>Elementum mattis vulputate ut euismod vitae nibh nam nulla sapien vehicula nec erat ut sodales tincidunt magna curabitur commodo leo eu felis rhoncus&hellip;</p>
    </article>
    <article class="one_third">
      <h3 class="font-x1 btmspace-30"><i class="fa fa-2x fa-pied-piper-alt rightspace-10"></i> <a href="#">Vestibulum odio</a></h3>
      <p>Elit nisi tincidunt bibendum lectus condimentum non etiam pulvinar erat et tristique tempor nisi lectus ultricies sapien bibendum interdum sapien&hellip;</p>
    </article>
    <!-- ################################################################################################ -->
    <!-- / main body -->
    </div>
    <div class="clear"></div>
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

<div class="wrapper_row3" style="background-color: rgba(242, 241, 238, 0.8); color: #4A4A4A; margin-bottom: 3%; ">
<div class='article_content_row4'>
  <section class="hoc container clear">
    <!-- ################################################################################################ -->
    <div class="center btmspace-50">
      <h2 class="heading">Какая то информация</h2>
      <p>Возможно это будут статьи. Или видео. Или выбранные фото</p>
    </div>
    <ul class="nospace group">
      <li class="one_third first">
        <article class="element">
          <figure><img src="images/demo/320x210.png" alt="">
            <figcaption><a href="#"><i class="fa fa-eye"></i></a></figcaption>
          </figure>
          <div class="excerpt">
            <h6 class="heading">Заголовок статьи</h6>
            <time datetime="2017-09-01">2<sup>th</sup> сентября 2017</time>
            <p>текст статьи&hellip;</p>
            <footer><a href="#">Читать полностью &raquo;</a></footer>
          </div>
        </article>
      </li>
      <li class="one_third">
        <article class="element">
          <iframe width="260" height="210" src="https://www.youtube.com/embed/DRa-WP6PDOE" frameborder="0" allowfullscreen></iframe>


          <div class="excerpt">
            <h6 class="heading">День открытых дверей в ХНУРЭ</h6>
            <time datetime="2045-04-05">5<sup>th</sup> April 2045</time>
            <p>Текст статьи&hellip;</p>
            <footer><a href="#">Читать полностью &raquo;</a></footer>
          </div>
        </article>
      </li>
      <li class="one_third">
        <article class="element">
          <figure><img src="images/demo/320x210.png" alt="">
            <figcaption><a href="#"><i class="fa fa-eye"></i></a></figcaption>
          </figure>
          <div class="excerpt">
            <h6 class="heading">Заголовок</h6>
            <time datetime="2045-04-05">5<sup>th</sup> April 2045</time>
            <p>текст статьи&hellip;</p>
            <footer><a href="#">Открыть полностью &raquo;</a></footer>
          </div>
        </article>
      </li>
    </ul>
   <div id="to_contact">
   <!-- ################################################################################################ -->
  </section>
  </div>
</div>

<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

<div class="wrapper row4 bgded overlay">
  <footer id="footer" class="hoc clear">
    <!-- ################################################################################################ -->
    <div id="cta" class="group">
      <div class="one_third first"><i class="fa fa-map-marker"></i>
        <p>Координаты</p>
        <p><a href="https://www.google.ru/maps/dir//50.0147362,36.2280767/@50.0151245,36.2258219,17z/data=!4m2!4m1!3e0">Построить маршрут</a></p>
        <p>Харьков, пр. Науки, 14 <br>3-й этаж <br> ауд.326</p>

      </div>
      <div class="one_third"><i class="fa fa-phone"></i>
        <p>Связаться с нами</p>
        <p><a href = "callto:+380577021484">+38 (057) 702 14 84</a></p>
        <p><a href="viber://chat?number=xxxxxxxxxxxxxxxx">Viber</a></p>

      </div>
      <div class="one_third"><i class="fa fa-envelope-o"></i>
        <p>Написать нам</p>
        <p><a href="mailto:d_pfee@nure.ua?">d_pfee@nure.ua</a></p>
      </div>
    </div>
    </div>
    <!-- ################################################################################################ -->

    <!-- ################################################################################################ -->
  </footer>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

<div class="wrapper row5" ">
  <div id="social" class="hoc clear">
    <!-- ################################################################################################ -->
    <div class="one_half first">
      <h6 class="title">Найти нас</h6>
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
        <li><a class="faicon-youtube" href="#"><i class="fa fa-youtube"></i></a></li>
      </ul>
    </div>
   <!-- <div class="one_half">
      <h6 class="title">Newsletter subscription</h6>
      <form class="clear" method="post" action="#">
        <fieldset>
          <legend>Newsletter:</legend>
          <input type="text" value="" placeholder="Введите ваш email&hellip;">
          <button class="fa fa-share" type="submit" title="Submit"><em>Submit</em></button>
        </fieldset>
      </form>
    </div>
    -->
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row6">
  <div id="copyright" class="hoc clear">
    <!-- ################################################################################################ -->
    <p class="fl_left">Кафедра Фотоники и Лазерной Инженерии &copy; 2017 <a href="#">адрес-сайта.домен</a></p>
    <p class="fl_right">Разработчик <a target="_blank" href="http://">Кто разработал</a></p>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/to_id_animated.js"></script>
<script src="layout/scripts/jquery.PageScroll2id.js"></script>
<!--<script src="layout/scripts/jquery.mobilemenu.js"></script> -->


<!-- IE9 Placeholder Support -->
<script src="layout/scripts/jquery.placeholder.min.js"></script>
<!-- / IE9 Placeholder Support -->

<!-- Preloader -->
<style type="text/css">#hellopreloader>p{display:none;}
#hellopreloader_preload{display: block;
position: fixed;
z-index: 99999;
top: 0;
left: 0;
width: 100%;
height: 100%;
min-width: 1000px;
background: white url(layout/scripts/preloader/nure_animated.gif) center center no-repeat;background-size:41px;}
</style>

<div id="hellopreloader"><div id="hellopreloader_preload"></div><p></p></div>
<script type="text/javascript">var hellopreloader = document.getElementById("hellopreloader_preload");
function fadeOutnojquery(el){el.style.opacity = 1;
var interhellopreloader = setInterval(function(){el.style.opacity = el.style.opacity - 0.05;
if (el.style.opacity <=0.05){ clearInterval(interhellopreloader);
hellopreloader.style.display = "none";}},16);}
window.onload = function(){setTimeout(function(){fadeOutnojquery(hellopreloader);},1000);};</script>



</body>
</content>
</html>