<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Галерея</title>
    <link rel="shortcut icon" type="image/x-icon" href="../images/icon.ico">
    <?php require '../layout/scripts/preloader/preloader.php'; ?>
    <link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
    <link href="../layout/styles/header.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="../layout/scripts/fancybox/jquery-1.4.3.min.js"></script>
    <script type="text/javascript" src="../layout/scripts/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
    <script type="text/javascript" src="../layout/scripts/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" type="text/css" href="../layout/scripts/fancybox/jquery.fancybox-1.3.4.css" media="screen" />

    Gallery Script  
<script type="text/javascript">
    $(document).ready(function(){
        $("a.photo").fancybox();
});
</script> 


<script type="text/javascript">
    $('.photo_gallery').magnificPopup({
        delegate: 'a',
        type: 'image',
        gallery: {enabled: true}
    });    
</script>




</head>
<body id="top">
<style type="text/css"></style>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

    <!-- HEADER -->
    <header>

        <!-- MENU BLOCK -->
        <div class="menu_block">

            <!-- CONTAINER -->
            <!--   <div class="container clearfix"> --

                 <!-- LOGO -->
            <div class="logo pull-left">
                <img src="../nure1.png">

            </div><!-- //LOGO -->

            <!-- SEARCH FORM
            <div id="search-form" class="pull-right">
              <form method="get" action="#">
                <input type="text" name="Search" value="Search" onFocus="if (this.value == 'Search') this.value = '';" onBlur="if (this.value == '') this.value = 'Search';" />
              </form>
            </div>
            SEARCH FORM -->

            <!-- MENU -->
            <div class="pull-right">
                <nav class="navmenu center">
                    <ul>
                        <li class="scroll_btn"><a href="../index.php" >Главная</a></li>
                        <li class="first active scroll_btn"><a href="photogallery.php" >Галерея</a></li>
                        <li class="scroll_btn"><a href="#" >Абитуриенту</a></li>
                        <li class="scroll_btn"><a href="#">Новости</a></li>
                        <li class="scroll_btn"><a href="#">О Кафедре</a></li>
                        <li class="scroll_btn"><a href="http://cist.nure.ua/ias/app/tt/f?p=778:2:1917547441500311::NO#" >Расписание</a></li>
                        <li class="scroll_btn last"><a href="#to_contact" >Контакты</a>
                    </ul>
                    </li>
                    </ul>
                </nav>
            </div><!-- //MENU -->
        </div><!-- //MENU BLOCK -->
        </div><!-- //CONTAINER -->
    </header><!-- //HEADER -->
    </ul>
    </nav>
    </div>

    <!-- Gallery -->

<div class="wrapper bgded" style="background-color: rgba(242, 241, 238, 0.8); margin-bottom: 3%; margin-top: 200px; ">
<div class="photo_gallery">
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/1.jpg"><img src="../images/demo/gallery/small/1.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/2.jpg"><img src="../images/demo/gallery/small/2.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/3.jpg"><img src="../images/demo/gallery/small/3.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/4.jpg"><img src="../images/demo/gallery/small/4.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/5.jpg"><img src="../images/demo/gallery/small/5.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/6.jpg"><img src="../images/demo/gallery/small/6.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/7.jpg"><img src="../images/demo/gallery/small/7.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/8.jpg"><img src="../images/demo/gallery/small/8.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/9.jpg"><img src="../images/demo/gallery/small/9.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/10.jpg"><img src="../images/demo/gallery/small/10.jpg"></a>
    <!--#############################################################################################################-->
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/1.jpg"><img src="../images/demo/gallery/small/1.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/2.jpg"><img src="../images/demo/gallery/small/2.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/3.jpg"><img src="../images/demo/gallery/small/3.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/4.jpg"><img src="../images/demo/gallery/small/4.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/5.jpg"><img src="../images/demo/gallery/small/5.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/6.jpg"><img src="../images/demo/gallery/small/6.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/7.jpg"><img src="../images/demo/gallery/small/7.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/8.jpg"><img src="../images/demo/gallery/small/8.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/9.jpg"><img src="../images/demo/gallery/small/9.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/10.jpg"><img src="../images/demo/gallery/small/10.jpg"></a>
    <!--#############################################################################################################-->
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/1.jpg"><img src="../images/demo/gallery/small/1.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/2.jpg"><img src="../images/demo/gallery/small/2.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/3.jpg"><img src="../images/demo/gallery/small/3.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/4.jpg"><img src="../images/demo/gallery/small/4.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/5.jpg"><img src="../images/demo/gallery/small/5.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/6.jpg"><img src="../images/demo/gallery/small/6.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/7.jpg"><img src="../images/demo/gallery/small/7.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/8.jpg"><img src="../images/demo/gallery/small/8.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/9.jpg"><img src="../images/demo/gallery/small/9.jpg"></a>
    <a rel="photo_gallery" class="photo" href="../images/demo/gallery/big/10.jpg"><img src="../images/demo/gallery/small/10.jpg"></a>
    <!--#############################################################################################################-->
   


   
</div>
</div>
<!--FOOTER-->
 <div id="to_contact">
<div class="wrapper row4 bgded overlay">
  <footer id="footer" class="hoc clear">
    <!-- ################################################################################################ -->
    <div id="cta" class="group">
      <div class="one_third first"><i class="fa fa-map-marker"></i>
        <p>Координаты</p>
        <p><a href="https://www.google.ru/maps/dir//50.0147362,36.2280767/@50.0151245,36.2258219,17z/data=!4m2!4m1!3e0">Построить маршрут</a></p>
        <p>Харьков, пр. Науки, 14 <br>3-й этаж <br> ауд.326</p>

      </div>
      <div class="one_third"><i class="fa fa-phone"></i>
        <p>Связаться с нами</p>
        <p><a href = "callto:+380577021484">+38 (057) 702 14 84</a></p>
        <p><a href="viber://chat?number=xxxxxxxxxxxxxxxx">Viber</a></p>

      </div>
      <div class="one_third"><i class="fa fa-envelope-o"></i>
        <p>Написать нам</p>
        <p><a href="mailto:d_pfee@nure.ua?">d_pfee@nure.ua</a></p>
      </div>
    </div>
    </div>
    <!-- ################################################################################################ -->

    <!-- ################################################################################################ -->
  </footer>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

<div class="wrapper row5" ">
  <div id="social" class="hoc clear">
    <!-- ################################################################################################ -->
    <div class="one_half first">
      <h6 class="title">Найти нас</h6>
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
        <li><a class="faicon-youtube" href="#"><i class="fa fa-youtube"></i></a></li>
      </ul>
    </div>
   <!-- <div class="one_half">
      <h6 class="title">Newsletter subscription</h6>
      <form class="clear" method="post" action="#">
        <fieldset>
          <legend>Newsletter:</legend>
          <input type="text" value="" placeholder="Введите ваш email&hellip;">
          <button class="fa fa-share" type="submit" title="Submit"><em>Submit</em></button>
        </fieldset>
      </form>
    </div>
    -->
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row6">
  <div id="copyright" class="hoc clear">
    <!-- ################################################################################################ -->
    <p class="fl_left">Кафедра Фотоники и Лазерной Инженерии &copy; 2017 <a href="#">адрес-сайта.домен</a></p>
    <p class="fl_right">Разработчик <a target="_blank" href="http://">Кто разработал</a></p>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>

<!-- JAVASCRIPTS -->


<!--##############################################################-->
<!-- Если подключена эта версия jquerry, не работает галерея -->
<!-- <script src="../layout/scripts/jquery.min.js"></script>  -->
<!--###############################################################-->

<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/to_id_animated.js"></script>
<script src="../layout/scripts/jquery.PageScroll2id.js"></script>



</body>
</html>