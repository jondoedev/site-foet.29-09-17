<?php
/**
 * Created by PhpStorm.
 * User: kalenyukk
 * Date: 22.08.2017
 * Time: 21:29
 */

/* Создает массив с общими настройками */

$config = array(
                'title' => 'Кафедра Фотоники и Лазерной Инженерии',
                'db' => array(
                    'server' => 'localhost',
                    'user' => 'root',
                    'password' => '',
                    'db_name' => 'blog_db'));