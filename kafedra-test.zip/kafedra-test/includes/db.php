<?php
/**
 * Created by PhpStorm.
 * User: kalenyukk
 * Date: 22.08.2017
 * Time: 21:34
 */


/* Создаем переменную с настройками для подключения к базе данных*/

require_once 'config.php';

$database_connection = mysqli_connect(
    $config =['db']['server'],
    $config =['db']['user'],
    $config =['db']['password'],
    $config =['db']['db_name']
);

if ($database_connection == false) {
    echo "Не удалось подключится к БД<br>";
    echo mysqli_connect_error();
    exit();
}

?>